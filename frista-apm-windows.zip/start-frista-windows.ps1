$ErrorActionPreference = "Stop"

$repoRoot = $PSScriptRoot
$botSource = Join-Path $repoRoot "jkn-biometrik-bot"
$agentSource = Join-Path $repoRoot "tools\frista-agent"
$botDestination = "C:\jkn-biometrik-bot"
$agentDestination = "C:\frista-agent"
$fristaExecutable = "C:\frista\frista.exe"
$logDirectory = "C:\frista-services\logs"

function Import-DotEnv([string]$path) {
    if (-not (Test-Path $path)) { return }
    foreach ($line in Get-Content $path) {
        if ($line -notmatch '^\s*([A-Za-z_][A-Za-z0-9_]*)=(.*)$') { continue }
        $name = $Matches[1]
        $value = $Matches[2].Trim()
        if (($value.StartsWith('"') -and $value.EndsWith('"')) -or
            ($value.StartsWith("'") -and $value.EndsWith("'"))) {
            $value = $value.Substring(1, $value.Length - 2)
        }
        if ([string]::IsNullOrWhiteSpace([Environment]::GetEnvironmentVariable($name, "Process"))) {
            [Environment]::SetEnvironmentVariable($name, $value, "Process")
        }
    }
}

function Test-Health([string]$url) {
    try {
        Invoke-RestMethod -Uri $url -TimeoutSec 2 | Out-Null
        return $true
    } catch {
        return $false
    }
}

function Wait-Health([string]$name, [string]$url) {
    for ($attempt = 1; $attempt -le 30; $attempt++) {
        if (Test-Health $url) {
            Write-Host "$name aktif: $url" -ForegroundColor Green
            return
        }
        Start-Sleep -Milliseconds 500
    }
    throw "$name gagal aktif. Periksa log di $logDirectory."
}

if ($env:OS -ne "Windows_NT") {
    throw "Script ini hanya dapat dijalankan pada Windows."
}
if (-not (Test-Path $botSource)) {
    throw "Folder sumber tidak ditemukan: $botSource"
}
if (-not (Test-Path $agentSource)) {
    throw "Folder sumber tidak ditemukan: $agentSource"
}
if (-not (Test-Path $fristaExecutable)) {
    throw "Frista tidak ditemukan: $fristaExecutable"
}

$node = Get-Command node.exe -ErrorAction SilentlyContinue
$npm = Get-Command npm.cmd -ErrorAction SilentlyContinue
$bun = Get-Command bun.exe -ErrorAction SilentlyContinue
if (-not $node -or -not $npm) {
    throw "Node.js dan npm belum terpasang. Gunakan Node.js 20.14.0."
}
if (-not $bun) {
    throw "Bun belum terpasang. Instal dari https://bun.sh lalu jalankan ulang script."
}

Import-DotEnv (Join-Path $repoRoot ".env")
if ([string]::IsNullOrWhiteSpace($env:FRISTA_AGENT_SHARED_SECRET) -or
    $env:FRISTA_AGENT_SHARED_SECRET.Length -lt 32) {
    throw "FRISTA_AGENT_SHARED_SECRET wajib diisi minimal 32 karakter di .env."
}
if ([string]::IsNullOrWhiteSpace($env:FRISTA_USERNAME) -or
    [string]::IsNullOrWhiteSpace($env:FRISTA_PASSWORD)) {
    throw "FRISTA_USERNAME dan FRISTA_PASSWORD wajib diisi di .env."
}
if ([string]::IsNullOrWhiteSpace($env:FRISTA_ALLOWED_ORIGIN)) {
    $env:FRISTA_ALLOWED_ORIGIN = if ($env:APP_URL) { $env:APP_URL } else { "http://localhost:3886" }
}
if ([string]::IsNullOrWhiteSpace($env:FRISTA_BOT_URL)) {
    $env:FRISTA_BOT_URL = "http://127.0.0.1:3000/?app=frista"
}

New-Item -ItemType Directory -Force -Path $botDestination, $agentDestination, $logDirectory | Out-Null
Copy-Item -Path (Join-Path $botSource "*") -Destination $botDestination -Recurse -Force
Copy-Item -Path (Join-Path $agentSource "*") -Destination $agentDestination -Recurse -Force

if (-not (Test-Path (Join-Path $botDestination "node_modules\node-autoit-koffi"))) {
    Write-Host "Memasang dependency JKN Biometrik Bot..."
    $install = Start-Process -FilePath $npm.Source `
        -ArgumentList @("install", "--omit=dev") `
        -WorkingDirectory $botDestination `
        -Wait -PassThru -NoNewWindow
    if ($install.ExitCode -ne 0) {
        throw "npm install gagal dengan exit code $($install.ExitCode)."
    }
}

$botHealth = "http://127.0.0.1:3000/?app=frista"
if (-not (Test-Health $botHealth)) {
    Start-Process -FilePath $node.Source `
        -ArgumentList @((Join-Path $botDestination "index.js")) `
        -WorkingDirectory $botDestination `
        -WindowStyle Hidden `
        -RedirectStandardOutput (Join-Path $logDirectory "jkn-biometrik-bot.out.log") `
        -RedirectStandardError (Join-Path $logDirectory "jkn-biometrik-bot.err.log")
}
Wait-Health "JKN Biometrik Bot" $botHealth

$agentHealth = "http://127.0.0.1:3001/health"
if (-not (Test-Health $agentHealth)) {
    Start-Process -FilePath $bun.Source `
        -ArgumentList @("run", (Join-Path $agentDestination "index.ts")) `
        -WorkingDirectory $agentDestination `
        -WindowStyle Hidden `
        -RedirectStandardOutput (Join-Path $logDirectory "frista-agent.out.log") `
        -RedirectStandardError (Join-Path $logDirectory "frista-agent.err.log")
}
Wait-Health "Frista Secure Agent" $agentHealth

Write-Host "Integrasi Frista siap digunakan oleh display APM." -ForegroundColor Green
Write-Host "Origin diizinkan: $env:FRISTA_ALLOWED_ORIGIN"
Write-Host "Log: $logDirectory"
