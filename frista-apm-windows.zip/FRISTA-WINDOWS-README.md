# Frista APM Windows

## Persiapan

1. Extract seluruh isi ZIP, disarankan ke `C:\apm-self-service`.
2. Pastikan Frista tersedia di `C:\frista\frista.exe`.
3. Pasang Node.js 20.14.0 dan Bun.
4. Salin `frista-windows.env.example` menjadi `.env`, lalu isi credential.

Secret `FRISTA_AGENT_SHARED_SECRET` harus sama dengan secret pada server APM.

## Jalankan

Buka PowerShell sebagai Administrator:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\start-frista-windows.ps1
```

## Autostart setelah login Windows

Jalankan sebagai user kiosk yang akan login:

```powershell
.\install-frista-autostart.ps1
```

Bot dan agent membutuhkan sesi desktop Windows aktif. Autostart berjalan setelah user kiosk login, bukan sebelum login.

## Pemeriksaan

```powershell
Invoke-RestMethod "http://127.0.0.1:3000/?app=frista"
Invoke-RestMethod "http://127.0.0.1:3001/health"
```

Log tersimpan di `C:\frista-services\logs`.
