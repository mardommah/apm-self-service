# Define the Node.js LTS version
$nodeVersion = "20.14.0"
$nodeLtsUrl64 = "https://nodejs.org/dist/v$nodeVersion/node-v$nodeVersion-x64.msi"
$nodeLtsUrl32 = "https://nodejs.org/dist/v$nodeVersion/node-v$nodeVersion-x86.msi"
$botFolder = "C:\jkn-biometrik-bot"

# Determine if the system is 64-bit or 32-bit
$is64Bit = [Environment]::Is64BitOperatingSystem
$nodeLtsUrl = if ($is64Bit) { $nodeLtsUrl64 } else { $nodeLtsUrl32 }

# Refresh env variables in the current session
function Refresh-Env-Vars {
    $env:PATH = [System.Environment]::GetEnvironmentVariable("PATH", [System.EnvironmentVariableTarget]::Machine)
}

# Function to check if Node.js is installed
function Check-Nodejs {
    try {
        node -v
        return $true        
    } catch {
        return $false
    }
}

# Function to get the current Node.js version
function Get-NodejsVersion {
    $version = node -v 2>$null
    if ($version) {
        return $version.TrimStart("v")
    }
    return $null
}

# Function to install Node.js
function Install-Nodejs {
    $arch = if ($is64Bit) { 'x64' } else { 'x86' }
    $installerPath = "$env:TEMP\node-v$nodeVersion-$arch.msi"
    if (-Not (Test-Path $installerPath)) {
        Invoke-WebRequest -Uri $nodeLtsUrl -OutFile $installerPath
    }
    Start-Process msiexec.exe -ArgumentList "/i", $installerPath, "/passive", "/norestart" -Wait
    Refresh-Env-Vars
}

# Function to uninstall Node.js
function Uninstall-Nodejs {
    $nodePath = (Get-Command node).Source
    $uninstallerPath = (Get-ItemProperty -Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*" | Where-Object { $_.DisplayName -like "Node.js*" }).UninstallString
    if ($uninstallerPath) {
        Start-Process "msiexec.exe" -ArgumentList "/x", $uninstallerPath, "/passive", "/norestart" -Wait
    }
}

# Check if Node.js is installed
if (Check-Nodejs) {
    $currentVersion = Get-NodejsVersion
    if ($currentVersion -lt $nodeVersion) {
        Write-Output "Current Node.js version is $currentVersion. Upgrading to $nodeVersion."
        Uninstall-Nodejs
        Install-Nodejs
    } else {
        Write-Output "Node.js is already at version $currentVersion."
    }
} else {
    Write-Output "Node.js is not installed. Installing version $nodeVersion."
    Install-Nodejs
}

# Install only production dependencies
npm install --omit=dev

Refresh-Env-Vars

# Create start-bot.vbs file at TEMP
$vbsFilePath = "$env:TEMP\start-bot.vbs"
$vbsFileContent = @"
Set WshShell = CreateObject("WScript.Shell")
WshShell.CurrentDirectory = "C:\jkn-biometrik-bot"
WshShell.Run "node index.js", 0, False
"@

# Write start-bot.vbs file content
$vbsFileContent | Set-Content -Path $vbsFilePath -Encoding ASCII

# Move start-bot.vbs file to Startup folder
$startupFolder = [System.Environment]::GetFolderPath('Startup')
Move-Item -Path $vbsFilePath -Destination "$startupFolder\start-bot.vbs" -Force

Write-Output "Setup completed."
Read-Host -Prompt "Press Enter to close this window"
