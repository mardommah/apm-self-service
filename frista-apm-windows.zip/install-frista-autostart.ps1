$ErrorActionPreference = "Stop"

$launcher = Join-Path $PSScriptRoot "start-frista-windows.ps1"
if (-not (Test-Path $launcher)) {
    throw "Launcher tidak ditemukan: $launcher"
}

$startup = [Environment]::GetFolderPath("Startup")
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut((Join-Path $startup "Frista APM.lnk"))
$shortcut.TargetPath = "powershell.exe"
$shortcut.Arguments = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$launcher`""
$shortcut.WorkingDirectory = $PSScriptRoot
$shortcut.Save()

Write-Host "Autostart Frista dipasang untuk user Windows saat ini." -ForegroundColor Green
Write-Host "Shortcut: $(Join-Path $startup 'Frista APM.lnk')"
